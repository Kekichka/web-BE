Покрити тестами функції:
* getTotalPrice
* getOrdersByQuery