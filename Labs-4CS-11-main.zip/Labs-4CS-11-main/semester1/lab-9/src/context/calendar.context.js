import { createContext } from 'react';

const CalendarContext = createContext();

export default CalendarContext;