import './App.css';
import QuestionsComponent from './questions';

function App () {
  return (
    <div className="App">
      <QuestionsComponent />
    </div>
  );
}

export default App;
